package com.example.pizzaapplication.utils;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}