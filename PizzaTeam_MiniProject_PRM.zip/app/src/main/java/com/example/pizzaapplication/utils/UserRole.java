package com.example.pizzaapplication.utils;

public enum UserRole {
    ADMIN,
    USER,
    GUEST
}
